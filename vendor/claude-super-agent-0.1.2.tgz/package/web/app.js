import { element, button, handle, notify } from "./ui.js";
import { workbench, workers, history } from "./pages/workbench.js";
import { schedules, webhooks, memory } from "./pages/automations.js";
import { settings } from "./pages/settings.js";

const pages = {
  workbench: ["工作台", workbench],
  workers: ["Worker", workers],
  schedules: ["定时任务", schedules],
  hooks: ["Webhook", webhooks],
  memory: ["记忆", memory],
  history: ["消息记录", history],
  settings: ["设置", settings],
};
const content = document.querySelector("#content");
const workspace = document.querySelector("#workspace");
const route = document.querySelector("#route");
let state;
let updateView;
let events;
let scope = {};
let sequence = 0;

function url(endpoint, query = {}) {
  const target = new URL("./api/" + endpoint, document.baseURI);
  for (const [key, value] of Object.entries({ ...scope, ...query })) {
    if (value !== "" && value != null) {
      target.searchParams.set(key, value);
    }
  }
  return target;
}

async function fetchJson(endpoint, options, query) {
  const response = await fetch(url(endpoint, query), options);
  if (!response.ok) {
    const error = await response.json().catch(() => ({}));
    throw Error(error.error || "HTTP " + response.status);
  }
  return response.json();
}

const get = (endpoint, query) => fetchJson(endpoint, {}, query);
const post = (endpoint, body = {}) =>
  fetchJson(endpoint, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });

async function action(endpoint, body) {
  await post(endpoint, body);
  await reload();
  notify("已保存");
}

function replaceOptions(select, options, value) {
  select.replaceChildren(...options.map(([id, label]) => new Option(label, id)));
  select.value = value;
}

async function reload() {
  const version = ++sequence;
  const snapshot = await get("state");
  if (version !== sequence) {
    return;
  }
  state = snapshot;
  scope = { workspace: state.workspace.id, route: state.route };
  replaceOptions(
    workspace,
    state.workspaces.map((id) => [id, id]),
    scope.workspace,
  );
  replaceOptions(
    route,
    state.routes.map((r) => [r.id, r.label]),
    scope.route,
  );
  const key = location.hash.slice(1) in pages ? location.hash.slice(1) : "workbench";
  document.querySelector("#heading").textContent = pages[key][0];
  document
    .querySelectorAll("nav button")
    .forEach((node) =>
      node.setAttribute("aria-current", node.dataset.key === key ? "page" : "false"),
    );
  updateView = null;
  const view = await pages[key][1]({
    get,
    post,
    action,
    reload,
    get state() {
      return state;
    },
    onUpdate: (fn) => {
      updateView = fn;
    },
  });
  if (version !== sequence) {
    return;
  }
  content.replaceChildren(view);
  if (events?.url !== url("events").href) {
    events?.close();
    events = new EventSource(url("events"));
    const connection = document.querySelector("#connection");
    events.onopen = () => {
      connection.textContent = "服务已连接";
    };
    events.onerror = () => {
      connection.textContent = "正在重新连接";
    };
    events.onmessage = handle(async () => {
      if (!updateView) {
        return;
      }
      const version = sequence;
      const snapshot = await get("state");
      if (version === sequence && updateView) {
        state = snapshot;
        await updateView();
      }
    });
  }
}

for (const [key, [title]] of Object.entries(pages)) {
  const link = button(title, () => {
    location.hash = key;
  });
  link.dataset.key = key;
  document.querySelector("nav").append(link);
}
workspace.addEventListener(
  "change",
  handle(async () => {
    scope = { workspace: workspace.value };
    await reload();
  }),
);
route.addEventListener(
  "change",
  handle(async () => {
    scope.route = route.value;
    await reload();
  }),
);
window.addEventListener("hashchange", handle(reload));
reload().catch((error) => notify(error.message, true));
