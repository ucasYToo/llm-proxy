import {
  element,
  section,
  group,
  item,
  rows,
  form,
  field,
  button,
  time,
  statusName,
  notify,
} from "../ui.js";

export function schedules(ctx) {
  const scheduleType = field("重复方式", "mode", {
    choices: [
      ["once", "一次性"],
      ["daily", "每天"],
      ["weekday", "工作日"],
      ["weekly", "每周"],
      ["cron", "自定义 cron"],
    ],
  });
  const once = field("执行时间", "at", { type: "datetime-local" });
  const hour = field("本地时间", "clock", { type: "time", value: "09:00" });
  const day = field("星期", "day", {
    choices: ["日", "一", "二", "三", "四", "五", "六"].map((d, i) => [i, "星期" + d]),
  });
  const cron = field("Cron（五段）", "cron", { placeholder: "0 17 * * 5" });
  function toggle() {
    const mode = scheduleType.lastChild.value;
    once.hidden = mode !== "once";
    cron.hidden = mode !== "cron";
    day.hidden = mode !== "weekly";
    hour.hidden = ["once", "cron"].includes(mode);
  }
  scheduleType.addEventListener("change", toggle);
  toggle();
  const create = form(
    [
      field("标题", "title", { required: true }),
      field("任务说明", "prompt", { long: true, required: true }),
      scheduleType,
      once,
      hour,
      day,
      cron,
      field("时区", "tz", {
        value: ctx.state.workspace.timezone || Intl.DateTimeFormat().resolvedOptions().timeZone,
      }),
    ],
    "添加定时任务",
    async (data) => {
      const [h, m] = data.clock.split(":").map(Number);
      const pattern =
        data.mode === "cron"
          ? data.cron
          : [
              m,
              h,
              "*",
              "*",
              data.mode === "weekly" ? data.day : data.mode === "weekday" ? "1-5" : "*",
            ].join(" ");
      await ctx.action("tasks/add", {
        title: data.title,
        prompt: data.prompt,
        tz: data.tz,
        ...(data.mode === "once" ? { at: new Date(data.at).toISOString() } : { cron: pattern }),
      });
    },
  );
  const list = rows(
    ctx.state.tasks,
    (task) => {
      const act = (title, op) => button(title, () => ctx.action("tasks/" + op, { id: task.id }));
      const buttons =
        task.state === "pending"
          ? [act("批准", "approve"), act("拒绝", "reject")]
          : [
              act("运行一次", "run"),
              ...(task.state === "active"
                ? [act("暂停", "pause")]
                : task.state === "paused"
                  ? [act("恢复", "resume")]
                  : []),
            ];
      buttons.push(act("删除", "remove"));
      return item(
        task.title,
        statusName(task.state) + " · " + (task.cron || "单次") + " · 下次 " + time(task.next),
        buttons,
      );
    },
    "暂无定时任务。",
  );
  return group("split", section("定时任务", list), section("新建任务", create));
}

export function webhooks(ctx) {
  const editor = element("div");
  async function showSecret(result) {
    const url = new URL("./api/webhook/" + result.secret, document.baseURI).href;
    await ctx.reload();
    notify("本次生成的调用地址：" + url);
  }
  function edit(hook) {
    editor.replaceChildren(
      form(
        [
          field("名称", "title", { value: hook?.title, required: true }),
          field("处理指令", "prompt", { long: true, value: hook?.prompt, required: true }),
        ],
        hook ? "保存修改" : "创建 Webhook",
        async (data) => {
          if (hook) {
            await ctx.action("hooks/edit", { id: hook.id, ...data });
          } else {
            await showSecret(await ctx.post("hooks/add", data));
          }
        },
      ),
    );
  }
  edit();
  const list = rows(
    ctx.state.hooks,
    (hook) =>
      item(hook.title, (hook.enabled ? "已启用" : "已停用") + " · " + hook.prompt, [
        button("编辑", () => edit(hook)),
        button(hook.enabled ? "停用" : "启用", () =>
          ctx.action("hooks/" + (hook.enabled ? "disable" : "enable"), { id: hook.id }),
        ),
        button("轮换地址", async () => showSecret(await ctx.post("hooks/rotate", { id: hook.id }))),
        button("删除", () => ctx.action("hooks/remove", { id: hook.id })),
      ]),
    "暂无 Webhook。",
  );
  return group("split", section("Webhook", list), section("配置触发器", editor));
}

export async function memory(ctx) {
  const menu = field("文件", "name", { choices: ctx.state.memory.map((n) => [n, n]) });
  const name = field("文件名", "file", { value: "SOUL.md", required: true });
  const body = field("内容", "text", { long: true });
  body.lastChild.rows = 12;
  const change = async () => {
    name.lastChild.value = menu.lastChild.value;
    body.lastChild.value = (await ctx.get("memory", { name: menu.lastChild.value })).text;
  };
  menu.addEventListener("change", () => change().catch((e) => notify(e.message, true)));
  await change();
  const editor = form([menu, name, body], "保存文件", (data) =>
    ctx.action("memory/save", { name: data.file, text: data.text }),
  );
  const diff = element("pre", "bodytext");
  return section(
    "人格与工作区记忆",
    editor,
    group(
      "actions",
      button("立即整理", async () => {
        notify("正在整理当前会话的记忆…");
        await ctx.action("memory/consolidate");
      }),
      button("查看上次改动", async () => {
        diff.textContent = (await ctx.get("memory/diff")).text || "暂无改动。";
      }),
    ),
    diff,
  );
}
