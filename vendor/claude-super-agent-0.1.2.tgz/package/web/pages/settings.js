import { element, section, group, rows, item, form, field, button } from "../ui.js";

export function settings(ctx) {
  const workspace = ctx.state.workspace;
  const runtime = form(
    [
      field("主模型", "model", { value: workspace.model }),
      field("图片模型", "visionModel", {
        value: workspace.visionModel,
        placeholder: "留空使用主模型",
      }),
      field("辅助模型", "auxiliaryModel", { value: workspace.auxiliaryModel }),
      field("时区", "timezone", {
        value: workspace.timezone || Intl.DateTimeFormat().resolvedOptions().timeZone,
      }),
      field("夜间整理时间（清空可关闭）", "consolidateAt", {
        type: "time",
        value: workspace.consolidateAt ?? "03:00",
      }),
      field("单轮时限（分钟）", "turnTimeoutMinutes", {
        type: "number",
        value: workspace.turnTimeoutMinutes || 30,
      }),
    ],
    "保存运行设置",
    (data) =>
      ctx.action("workspace/save", {
        ...data,
        turnTimeoutMinutes: Number(data.turnTimeoutMinutes),
      }),
  );
  const panels = [section("工作区设置", element("p", "detail", workspace.cwd), runtime)];
  const config = ctx.state.settings;
  if (!config) {
    return group("stack", ...panels);
  }
  const activeWorkspace = ctx.state.status.selected;
  if (activeWorkspace !== workspace.id) {
    panels.push(
      section(
        "工作区调度",
        element(
          "p",
          "detail",
          activeWorkspace ? "当前启用 " + activeWorkspace : "当前所有工作区均可运行任务。",
        ),
        button("只启用此工作区", () => ctx.action("workspace/select", {})),
      ),
    );
  }
  panels.push(
    section(
      "添加工作区",
      form(
        [field("标识", "id", { required: true }), field("本机绝对路径", "cwd", { required: true })],
        "添加工作区",
        (data) => ctx.action("settings/save", { workspaces: [...config.workspaces, data] }),
      ),
    ),
  );
  if (activeWorkspace) {
    panels.push(button("恢复所有工作区调度", () => ctx.action("workspace/select", { all: true })));
  }
  const botEditor = element("div");
  function edit(bot = {}) {
    botEditor.replaceChildren(
      form(
        [
          field("机器人标识", "id", { required: true, value: bot.id }),
          field("App ID", "appId", { required: true, value: bot.appId }),
          field("App Secret", "appSecret", {
            type: "password",
            placeholder: bot.hasSecret ? "已保存，留空沿用" : "",
          }),
          field("密钥环境变量名", "appSecretEnv", { value: bot.appSecretEnv }),
          field("工作区", "workspaceId", {
            choices: config.workspaces.map((w) => [w.id, w.id]),
            value: bot.workspaceId || workspace.id,
          }),
          field("授权 open_id（每行一个）", "allowed", {
            long: true,
            value: bot.allowedOpenIds?.join("\n"),
            placeholder: "可先留空保存。私聊机器人，复制它回复的 open_id，填到这里再保存。",
          }),
        ],
        "保存机器人",
        (data) => {
          const { allowed, ...values } = data;
          return ctx.action("settings/save", {
            bots: [
              ...config.bots.filter((b) => b.id !== (bot.id || data.id)),
              { ...values, allowedOpenIds: allowed.split(/\s+/).filter(Boolean) },
            ],
          });
        },
      ),
    );
  }
  edit();
  const list = rows(
    config.bots,
    (bot) =>
      item(bot.id, bot.appId + " · " + bot.workspaceId, [
        button("编辑", () => edit(bot)),
        button("移除", () =>
          ctx.action("settings/save", { bots: config.bots.filter((b) => b.id !== bot.id) }),
        ),
      ]),
    "尚未连接飞书机器人。",
  );
  panels.push(section("飞书机器人", list, botEditor));
  return group("stack", ...panels);
}
