import {
  element,
  section,
  group,
  item,
  rows,
  form,
  field,
  button,
  time,
  statusName,
} from "../ui.js";

function messages(container, history) {
  container.replaceChildren(
    ...history
      .slice()
      .reverse()
      .map((message) => {
        const line = element("article", "message " + message.direction);
        line.append(
          element(
            "time",
            "",
            (message.direction === "in" ? "输入" : "助手") + " · " + time(message.created),
          ),
          element("p", "bodytext", message.text),
        );
        return line;
      }),
  );
  if (!history.length) {
    container.append(element("p", "empty", "还没有消息。"));
  }
  container.scrollTop = container.scrollHeight;
}

function jobList(ctx) {
  return rows(
    ctx.state.jobs,
    (job) => {
      const cancel = () => ctx.action("jobs/" + job.id + "/cancel");
      const row = item(
        "#" + job.id + " " + job.title,
        job.worker + " · " + statusName(job.state) + " · " + (job.progress || "等待开始"),
        ["queued", "running"].includes(job.state) ? [button("取消任务", cancel)] : [],
      );
      const timeline = [
        job.started && "开始 " + time(job.started),
        job.ended && "结束 " + time(job.ended),
        job.parent && "第 " + job.depth + " 层，接力 #" + job.parent,
        job.continued && "续跑 #" + job.continued,
      ].filter(Boolean);
      if (timeline.length) {
        row.append(element("p", "detail", timeline.join(" · ")));
      }
      if (job.result) {
        const details = element("details");
        details.append(element("summary", "", "查看结果"), element("p", "bodytext", job.result));
        row.append(details);
      }
      return row;
    },
    "暂无后台任务。",
  );
}

export async function workbench(ctx) {
  const feed = element("div", "feed");
  messages(feed, await ctx.get("history"));
  const compose = form(
    [field("消息", "text", { long: true }), field("附加图片", "attachment", { type: "file" })],
    "发送",
    async (data, form) => {
      const file = data.attachment;
      let image;
      if (file.size) {
        if (file.size > 5 * 1024 * 1024) {
          throw Error("图片需要在 5 MB 以内");
        }
        image = await new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => resolve(reader.result.split(",")[1]);
          reader.onerror = () => reject(Error("图片读取失败"));
          reader.readAsDataURL(file);
        });
      }
      await ctx.post("chat/send", { text: data.text, image, messageId: cryptoId() });
      form.reset();
      messages(feed, await ctx.get("history"));
    },
  );
  compose.elements.attachment.accept = "image/png,image/jpeg,image/gif,image/webp";
  const controls = group(
    "actions",
    ...[
      ["中断本轮", "/stop"],
      ["新会话", "/new"],
      ["恢复主会话", "/restart"],
    ].map(([title, text]) =>
      button(title, async () => {
        await ctx.post("chat/send", { text, messageId: cryptoId() });
        messages(feed, await ctx.get("history"));
      }),
    ),
  );
  const labels = {
    idle: "空闲",
    running: "处理中",
    paused: "连续失败，等待恢复",
    consolidating: "正在整理记忆",
  };
  const session = element("p", "detail", "主会话状态 · " + labels[ctx.state.sessionStatus]);
  const jobs = group("", jobList(ctx));
  ctx.onUpdate(async () => {
    messages(feed, await ctx.get("history"));
    session.textContent = "主会话状态 · " + labels[ctx.state.sessionStatus];
    jobs.replaceChildren(jobList(ctx));
  });
  return group(
    "split",
    section("主会话", session, feed, compose, controls),
    section("后台任务", jobs),
  );
}

function cryptoId() {
  const bytes = crypto.getRandomValues(new Uint8Array(16));
  return Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join("");
}

export async function history(ctx) {
  const feed = element("div", "feed");
  const refresh = async (filters) => messages(feed, await ctx.get("history", filters));
  const sources = [
    ["", "全部来源"],
    ["feishu", "飞书"],
    ["web", "Web"],
    ["worker", "后台任务"],
    ["review", "任务验收"],
    ["schedule", "定时任务"],
    ["hook", "Webhook"],
    ["external", "外部材料"],
    ["error", "错误"],
  ];
  const filters = form(
    [
      field("搜索文本", "q"),
      field("来源", "source", { choices: sources }),
      field("状态", "status", {
        choices: [
          ["", "全部"],
          ["failed", "失败"],
        ],
      }),
      field("开始时间", "from", { type: "datetime-local" }),
      field("结束时间", "to", { type: "datetime-local" }),
    ],
    "查询",
    (values) => {
      for (const key of ["from", "to"]) {
        if (values[key]) {
          values[key] = new Date(values[key]).getTime();
        }
      }
      return refresh(values);
    },
  );
  await refresh({});
  return section("消息检索", filters, feed);
}

export function workers(ctx) {
  const editor = element("div");
  function edit(w = {}) {
    editor.replaceChildren(
      form(
        [
          field("名称", "name", { value: w.name, required: true }),
          field("用途", "purpose", { value: w.purpose, required: true }),
          field("模型", "model", { value: w.model }),
          field("工作目录", "cwd", { value: w.cwd }),
          field("工具（逗号分隔）", "tools", {
            value: (w.tools || ["Read", "Glob", "Grep"]).join(","),
          }),
          field("工作说明", "instructions", { value: w.instructions, long: true }),
        ],
        "保存 Worker",
        (data) =>
          ctx.action("workers/save", {
            ...data,
            tools: data.tools
              .split(",")
              .map((v) => v.trim())
              .filter(Boolean),
          }),
      ),
    );
  }
  edit();
  const list = rows(
    ctx.state.workspace.workers || [],
    (w) =>
      item(w.name, w.purpose, [
        button("编辑", () => edit(w)),
        button("移除", () => ctx.action("workers/remove", { name: w.name })),
      ]),
    "尚未配置专属 Worker。",
  );
  return group(
    "split",
    section("Worker 列表", item("default", "通用任务 · 使用主模型"), list),
    section("配置 Worker", editor),
  );
}
